from django.http import HttpResponse
from .models import user
from django.shortcuts import render
def index(Request) :
    all_users = user.objects.all()
    context = {
    'all_users' : all_users,
    }
    return render(Request,"login/index.html",context)

def details(Request, user_id) :
    return HttpResponse("<p>Details for user id : " + str(user_id) + "</p>")
 
def capture(Request):
	import cv2 , time
	video = cv2.VideoCapture(0)
	a=0
	while True:
		a=a+1
		check, frame = video.read()

		gray = cv2.cvtColor(frame , cv2.COLOR_BGR2GRAY)
		cv2.imshow("Capturing" , frame)

		key = cv2.waitKey(1)
		if key == ord('q') :
			break

	video.release()
	return HttpResponse("<p>"+str(frame) +"</p>")